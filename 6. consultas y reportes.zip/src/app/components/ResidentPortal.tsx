import { CheckCircle2, XCircle, Clock, Download, CreditCard, AlertTriangle, Calendar, TrendingDown, Eye } from "lucide-react";

// ─── Datos ──────────────────────────────────────────────────────────────────
const CUENTAS: Record<"propietario" | "arrendatario", {
  nombre: string; apartamento: string; tipo: string; rut: string; gastosComunes: number;
  proximoVencimiento: string; historial: any[];
}> = {
  propietario: {
    nombre: "Patricia Herrera Vidal",
    apartamento: "Apto. 504 — Piso 5",
    tipo: "Propietaria",
    rut: "9.876.543-2",
    gastosComunes: 135000,
    proximoVencimiento: "2026-07-01",
    historial: [
      { id: "GC-0624", concepto: "Gastos Comunes — Junio 2026",    monto: 135000, vencimiento: "2026-06-01", estado: "pagado",   pagado: "2026-05-30" },
      { id: "GC-0524", concepto: "Gastos Comunes — Mayo 2026",     monto: 135000, vencimiento: "2026-05-01", estado: "pagado",   pagado: "2026-04-29" },
      { id: "GC-0424", concepto: "Gastos Comunes — Abril 2026",    monto: 135000, vencimiento: "2026-04-01", estado: "pagado",   pagado: "2026-03-31" },
      { id: "GC-0324", concepto: "Gastos Comunes — Marzo 2026",    monto: 135000, vencimiento: "2026-03-01", estado: "pagado",   pagado: "2026-02-28" },
      { id: "GC-0224", concepto: "Gastos Comunes — Febrero 2026",  monto: 135000, vencimiento: "2026-02-01", estado: "pagado",   pagado: "2026-01-31" },
      { id: "GC-0124", concepto: "Gastos Comunes — Enero 2026",    monto: 135000, vencimiento: "2026-01-01", estado: "pagado",   pagado: "2025-12-30" },
    ],
  },
  arrendatario: {
    nombre: "Roberto Cruz Valdivia",
    apartamento: "Apto. 504 — Piso 5",
    tipo: "Arrendatario",
    rut: "12.345.678-9",
    gastosComunes: 120000,
    proximoVencimiento: "2026-07-01",
    historial: [
      { id: "GC-0624", concepto: "Gastos Comunes — Junio 2026",    monto: 120000, vencimiento: "2026-06-01", estado: "pagado",   pagado: "2026-05-28" },
      { id: "GC-0524", concepto: "Gastos Comunes — Mayo 2026",     monto: 120000, vencimiento: "2026-05-01", estado: "pagado",   pagado: "2026-04-30" },
      { id: "GC-0424", concepto: "Gastos Comunes — Abril 2026",    monto: 120000, vencimiento: "2026-04-01", estado: "vencido",  pagado: null },
      { id: "GC-0324", concepto: "Gastos Comunes — Marzo 2026",    monto: 120000, vencimiento: "2026-03-01", estado: "vencido",  pagado: null },
      { id: "GC-0224", concepto: "Gastos Comunes — Febrero 2026",  monto: 120000, vencimiento: "2026-02-01", estado: "pagado",   pagado: "2026-01-31" },
      { id: "GC-0124", concepto: "Gastos Comunes — Enero 2026",    monto: 120000, vencimiento: "2026-01-01", estado: "pagado",   pagado: "2025-12-30" },
      { id: "MUL-001", concepto: "Multa — Ruido reiterado",        monto:  50000, vencimiento: "2026-03-15", estado: "vencido",  pagado: null },
    ],
  },
};

const fmtCLP  = (n: number) => new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(Math.abs(n));
const fmtDate = (s: string | null) => s ? new Date(s).toLocaleDateString("es-CL", { day: "2-digit", month: "short", year: "numeric" }) : "—";

function EstadoBadge({ estado }: { estado: string }) {
  if (estado === "pagado") return (
    <span className="flex items-center gap-1 text-green-700 bg-green-50 px-2 py-0.5 rounded-full text-xs font-medium w-fit">
      <CheckCircle2 size={10} /> Pagado
    </span>
  );
  if (estado === "vencido") return (
    <span className="flex items-center gap-1 text-red-700 bg-red-50 px-2 py-0.5 rounded-full text-xs font-medium w-fit">
      <XCircle size={10} /> Vencido
    </span>
  );
  return (
    <span className="flex items-center gap-1 text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full text-xs font-medium w-fit">
      <Clock size={10} /> Pendiente
    </span>
  );
}

interface Props {
  viewAs: "propietario" | "arrendatario";
  /** Si true, es el propietario viendo la cuenta de su arrendatario */
  readOnly?: boolean;
}

export function ResidentPortal({ viewAs, readOnly = false }: Props) {
  const data   = CUENTAS[viewAs];
  const deuda  = data.historial.filter(e => e.estado === "vencido").reduce((s: number, e: any) => s + e.monto, 0);

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          {readOnly && (
            <div className="flex items-center gap-2 mb-2">
              <Eye size={14} className="text-accent" />
              <span className="text-xs font-semibold text-accent uppercase tracking-wider">Vista del propietario</span>
            </div>
          )}
          <h1 className="text-foreground">{readOnly ? "Cuenta de Mi Arrendatario" : "Mi Estado de Cuenta"}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Información en tiempo real · RF-17, RF-18</p>
        </div>
        {!readOnly && (
          <button className="flex items-center gap-2 text-xs bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors">
            <Download size={13} /> Descargar Informe
          </button>
        )}
      </div>

      {/* Resumen */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card rounded-xl border border-border p-5">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Residente</p>
              <h2 className="text-foreground">{data.nombre}</h2>
              <p className="text-sm text-muted-foreground mt-0.5">{data.apartamento} · {data.tipo}</p>
              <p className="text-sm text-muted-foreground">RUT: {data.rut}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Saldo Adeudado</p>
              <p className={`text-2xl font-semibold ${deuda > 0 ? "text-red-600" : "text-green-600"}`}>
                {deuda > 0 ? "−" : ""}{fmtCLP(deuda)}
              </p>
              {deuda > 0 && (
                <p className="text-xs text-red-500 mt-0.5 flex items-center justify-end gap-1">
                  <AlertTriangle size={11} /> Requiere pago
                </p>
              )}
              {deuda === 0 && (
                <p className="text-xs text-green-600 mt-0.5 flex items-center justify-end gap-1">
                  <CheckCircle2 size={11} /> Al día
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center gap-2 mb-1">
              <Calendar size={13} className="text-muted-foreground" />
              <p className="text-xs text-muted-foreground">Próximo vencimiento</p>
            </div>
            <p className="font-semibold text-foreground">{fmtDate(data.proximoVencimiento)}</p>
            <p className="text-xs text-muted-foreground">{fmtCLP(data.gastosComunes)}</p>
          </div>
          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingDown size={13} className="text-muted-foreground" />
              <p className="text-xs text-muted-foreground">Cuotas vencidas</p>
            </div>
            {deuda > 0 ? (
              <>
                <p className="font-semibold text-red-600">{data.historial.filter((e: any) => e.estado === "vencido").length} cuota{data.historial.filter((e: any) => e.estado === "vencido").length > 1 ? "s" : ""}</p>
                <p className="text-xs text-muted-foreground">{fmtCLP(deuda)} total</p>
              </>
            ) : (
              <p className="font-semibold text-green-600">Sin vencidas</p>
            )}
          </div>
        </div>
      </div>

      {/* Alerta de mora */}
      {deuda > 0 && (
        <div className={`${readOnly ? "bg-amber-50 border-amber-200" : "bg-red-50 border-red-200"} border rounded-xl p-4 flex items-start gap-3`}>
          <AlertTriangle size={16} className={`${readOnly ? "text-amber-500" : "text-red-500"} shrink-0 mt-0.5`} />
          <div className="flex-1">
            <p className={`text-sm font-medium ${readOnly ? "text-amber-700" : "text-red-700"}`}>
              {readOnly
                ? `Su arrendatario tiene deuda por ${fmtCLP(deuda)}`
                : `Tiene deuda pendiente por ${fmtCLP(deuda)}`}
            </p>
            <p className={`text-xs mt-0.5 ${readOnly ? "text-amber-600" : "text-red-600"}`}>
              {readOnly
                ? "El no pago de gastos comunes por el arrendatario puede afectar su propiedad. Considere contactarlo."
                : "Tiene cuotas vencidas. El no pago puede generar intereses y restricciones en áreas comunes."}
            </p>
          </div>
          {!readOnly && (
            <button className="ml-auto shrink-0 flex items-center gap-1.5 text-xs bg-red-600 text-white px-3 py-1.5 rounded-lg hover:bg-red-700 transition-colors">
              <CreditCard size={12} /> Pagar ahora
            </button>
          )}
        </div>
      )}

      {/* Historial */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <h3 className="text-foreground">Historial de Pagos y Cargos</h3>
          <span className="text-xs text-muted-foreground">{data.historial.length} registros</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/50">
                {["N° Doc.", "Concepto", "Monto", "Vencimiento", "Fecha Pago", "Estado"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.historial.map((e: any, i: number) => (
                <tr key={e.id} className={`border-t border-border hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                  <td className="px-5 py-3.5"><span className="font-mono text-xs text-muted-foreground">{e.id}</span></td>
                  <td className="px-5 py-3.5 text-foreground">{e.concepto}</td>
                  <td className="px-5 py-3.5 font-medium text-foreground">{fmtCLP(e.monto)}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{fmtDate(e.vencimiento)}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{fmtDate(e.pagado)}</td>
                  <td className="px-5 py-3.5"><EstadoBadge estado={e.estado} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
