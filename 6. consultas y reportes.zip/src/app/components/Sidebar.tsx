import {
  Building2, LayoutDashboard, FileText, Search, Settings,
  Users, ChevronRight, Bell, LogOut, Home, UserCheck, Info,
} from "lucide-react";

export type Role = "admin" | "propietario" | "arrendatario";
export type AdminView = "dashboard" | "residents" | "search" | "query" | "settings";
export type PropietarioView = "mi-cuenta" | "mi-arrendatario" | "edificio";
export type ArrendatarioView = "mi-cuenta" | "edificio";
export type View = AdminView | PropietarioView | ArrendatarioView;

interface SidebarProps {
  activeView: View;
  onViewChange: (v: View) => void;
  role: Role;
  onRoleChange: (r: Role) => void;
  onLogout?: () => void;
}

const adminNav: { id: AdminView; label: string; icon: any }[] = [
  { id: "dashboard",  label: "Panel de Control",    icon: LayoutDashboard },
  { id: "residents",  label: "Residentes",           icon: Users },
  { id: "search",     label: "Búsqueda Avanzada",    icon: Search },
  { id: "query",      label: "Consultas e Informes", icon: FileText },
  { id: "settings",   label: "Configuración",        icon: Settings },
];

const propietarioNav: { id: PropietarioView; label: string; icon: any }[] = [
  { id: "mi-cuenta",        label: "Mi Estado de Cuenta",  icon: FileText },
  { id: "mi-arrendatario",  label: "Mi Arrendatario",      icon: UserCheck },
  { id: "edificio",         label: "Información Edificio", icon: Info },
];

const arrendatarioNav: { id: ArrendatarioView; label: string; icon: any }[] = [
  { id: "mi-cuenta",  label: "Mi Estado de Cuenta",  icon: FileText },
  { id: "edificio",   label: "Información Edificio", icon: Info },
];

const ROLES: { id: Role; label: string }[] = [
  { id: "admin",        label: "Admin" },
  { id: "propietario",  label: "Propietario" },
  { id: "arrendatario", label: "Arrendatario" },
];

const PERSONAS: Record<Role, { nombre: string; sub: string; initials: string }> = {
  admin:        { nombre: "Ana Martínez",          sub: "Administradora",    initials: "AM" },
  propietario:  { nombre: "Patricia Herrera Vidal", sub: "Propietaria · Apto. 504", initials: "PH" },
  arrendatario: { nombre: "Roberto Cruz Valdivia",  sub: "Arrendatario · Apto. 504", initials: "RC" },
};

export function Sidebar({ activeView, onViewChange, role, onRoleChange, onLogout }: SidebarProps) {
  const nav = role === "admin" ? adminNav : role === "propietario" ? propietarioNav : arrendatarioNav;
  const persona = PERSONAS[role];

  return (
    <aside className="flex flex-col bg-primary text-primary-foreground h-screen w-64 shrink-0">
      {/* Brand */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-white/10">
        <div className="w-9 h-9 rounded-lg bg-accent flex items-center justify-center shrink-0">
          <Building2 size={18} />
        </div>
        <div>
          <p className="text-sm font-semibold leading-none">GestiónHogar</p>
          <p className="text-xs text-white/50 mt-0.5">Edificio Las Torres</p>
        </div>
      </div>

      {/* Role switcher */}
      <div className="px-4 pt-4">
        <p className="text-xs text-white/40 uppercase tracking-wider mb-2 px-1">Perfil de acceso</p>
        <div className="flex bg-white/10 rounded-lg p-1 gap-0.5">
          {ROLES.map(r => (
            <button
              key={r.id}
              onClick={() => onRoleChange(r.id)}
              className={`flex-1 text-xs py-1.5 rounded-md transition-all font-medium ${
                role === r.id ? "bg-accent text-white" : "text-white/55 hover:text-white"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 pt-5 space-y-0.5 overflow-y-auto">
        <p className="text-xs text-white/40 uppercase tracking-wider mb-2 px-2">Menú</p>
        {nav.map(({ id, label, icon: Icon }) => {
          const active = activeView === id;
          return (
            <button
              key={id}
              onClick={() => onViewChange(id as View)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all group ${
                active ? "bg-accent text-white" : "text-white/65 hover:bg-white/10 hover:text-white"
              }`}
            >
              <Icon size={15} />
              <span className="flex-1 text-left">{label}</span>
              {active && <ChevronRight size={13} className="opacity-70" />}
            </button>
          );
        })}
      </nav>

      {/* User footer */}
      <div className="px-4 py-4 border-t border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-accent/30 flex items-center justify-center text-xs font-semibold shrink-0">
            {persona.initials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium truncate">{persona.nombre}</p>
            <p className="text-xs text-white/45 truncate">{persona.sub}</p>
          </div>
          <div className="flex gap-1">
            <button className="w-7 h-7 flex items-center justify-center text-white/45 hover:text-white transition-colors rounded">
              <Bell size={13} />
            </button>
            <button onClick={onLogout} className="w-7 h-7 flex items-center justify-center text-white/45 hover:text-white transition-colors rounded" title="Cerrar sesión">
              <LogOut size={13} />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
